import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar, QAction, QLineEdit,
    QVBoxLayout, QWidget, QTabWidget, QDialog,
    QCheckBox, QPushButton, QListWidget, QListWidgetItem, QFileDialog, QProgressBar, QMessageBox, QMenuBar, QMenu
)
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QUrl

class DownloadManager(QDialog):
    def __init__(self, parent=None):
        super(DownloadManager, self).__init__(parent)
        self.setWindowTitle("downloads (it has a few issues.)")
        self.setGeometry(300, 300, 400, 300)
        self.layout = QVBoxLayout()
        self.download_list = QListWidget()
        self.layout.addWidget(self.download_list)
        self.setLayout(self.layout)

    def add_download(self, download_item):
        item = QListWidgetItem(download_item.suggestedFileName())
        item.setData(1, download_item)
        item.setData(2, 0)
        item.setData(3, False)
        self.download_list.addItem(item)
        progress_bar = QProgressBar()
        progress_bar.setRange(0, 100)
        progress_bar.setValue(0)
        self.download_list.setItemWidget(item, progress_bar)
        download_path = os.path.join(self.select_download_directory(), download_item.suggestedFileName())
        download_item.setPath(download_path)
        download_item.accept()
        download_item.finished.connect(lambda: self.download_finished(download_item, item))
        download_item.downloadProgress.connect(lambda received, total: self.update_progress(item, received, total))

    def select_download_directory(self):
        directory = QFileDialog.getExistingDirectory(self, "Select Download Directory")
        return directory if directory else os.getcwd()

    def update_progress(self, item, received, total):
        if total > 0:
            progress = int((received / total) * 100)
            item.setData(2, progress)
            progress_bar = self.download_list.itemWidget(item)
            progress_bar.setValue(progress)

    def download_finished(self, download_item, item):
        QMessageBox.information(self, "download complete", f"download finished: {download_item.path()}")
        self.download_list.takeItem(self.download_list.row(item))

class ExtensionsDialog(QDialog):
    def __init__(self, extensions_dir, parent=None):
        super(ExtensionsDialog, self).__init__(parent)
        self.setWindowTitle("extensions")
        self.setGeometry(300, 300, 400, 300)
        self.layout = QVBoxLayout()
        self.extension_list = QListWidget()
        self.layout.addWidget(self.extension_list)
        self.load_extensions(extensions_dir)
        self.setLayout(self.layout)

    def load_extensions(self, extensions_dir):
        if os.path.exists(extensions_dir):
            for filename in os.listdir(extensions_dir):
                if filename.endswith(".py"):
                    item = QListWidgetItem(filename)
                    checkbox = QCheckBox(filename)
                    checkbox.setChecked(True)
                    self.extension_list.addItem(item)
                    self.extension_list.setItemWidget(item, checkbox)

class Browser(QMainWindow):
    def __init__(self):
        super(Browser, self).__init__()
        self.setWindowTitle("nyanbrowser")
        icon_path = os.path.join(os.path.dirname(__file__), "german.png")
        self.setWindowIcon(QIcon(icon_path))
        self.setGeometry(200, 200, 1200, 800)
        
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        self.setCentralWidget(self.tabs)
        
        self.toolbar = QToolBar()
        self.addToolBar(self.toolbar)
        
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        self.toolbar.addWidget(self.url_bar)

        self.create_menu_bar()
        
        self.add_new_tab("https://www.google.com")
        self.download_manager = DownloadManager(self)
        self.apply_dark_theme()
        self.show()

    def create_menu_bar(self):
        menu_bar = self.menuBar()
        
   
        menu = QMenu("Options", self)
        menu_bar.addMenu(menu)
        
 
        back_action = QAction("back", self)
        back_action.triggered.connect(lambda: self.tabs.currentWidget().back())
        menu.addAction(back_action)
        
        forward_action = QAction("forward", self)
        forward_action.triggered.connect(lambda: self.tabs.currentWidget().forward())
        menu.addAction(forward_action)
        
        refresh_action = QAction("refresh", self)
        refresh_action.triggered.connect(lambda: self.tabs.currentWidget().reload())
        menu.addAction(refresh_action)
        
        home_action = QAction("home", self)
        home_action.triggered.connect(self.navigate_home)
        menu.addAction(home_action)
        
        new_tab_action = QAction("new tab", self)
        new_tab_action.triggered.connect(lambda: self.add_new_tab())
        menu.addAction(new_tab_action)
        
        extensions_action = QAction("extensions", self)
        extensions_action.triggered.connect(self.show_extensions_dialog)
        menu.addAction(extensions_action)
        
        downloads_action = QAction("downloads", self)
        downloads_action.triggered.connect(self.show_download_manager)
        menu.addAction(downloads_action)

    def navigate_to_url(self):
        url = self.url_bar.text().strip()
        if not url:
            return
        if '.' not in url:
            url = f"https://www.google.com/search?q={url}"
        elif not url.startswith("http://") and not url.startswith("https://"):
            url = "https://" + url
        self.add_new_tab(url)

    def add_new_tab(self, url="https://www.google.com"):
        new_tab = QWebEngineView()
        new_tab.setUrl(QUrl(url))
        new_tab.titleChanged.connect(lambda title: self.update_tab_title(new_tab, title))
        new_tab.page().profile().downloadRequested.connect(self.start_download)
        self.tabs.addTab(new_tab, url)
        self.tabs.setCurrentWidget(new_tab)
        self.url_bar.setText(url)

    def close_current_tab(self, index):
        if self.tabs.count() < 2:
            return
        self.tabs.removeTab(index)

    def navigate_home(self):
        self.add_new_tab("https://www.google.com")

    def show_extensions_dialog(self):
        dialog = ExtensionsDialog("extensions/", self)
        dialog.exec_()

    def show_download_manager(self):
        self.download_manager.show()

    def start_download(self, download_item):
        self.download_manager.add_download(download_item)

    def update_tab_title(self, new_tab, title):
        index = self.tabs.indexOf(new_tab)
        if index >= 0:
            self.tabs.setTabText(index, title)

    def apply_dark_theme(self):
        self.setStyleSheet("""
            QMainWindow { background-color: black; color: white; }
            QToolBar { background-color: #333; }
            QLineEdit { background-color: #555; color: white; }
            QPushButton { background-color: #555; color: white; }
            QTabWidget::pane { background: #222; }
            QTabBar::tab { background: #333; color: white; }
        """)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    browser = Browser()
    sys.exit(app.exec_())
