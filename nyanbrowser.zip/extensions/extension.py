from PyQt5.QtWidgets import QAction, QMessageBox

class DarkModeExtension:
    def __init__(self, browser):
        self.browser = browser
        self.is_dark_mode = False  # Track the dark mode state

        # Create a toggle action for dark mode
        self.toggle_dark_mode_action = QAction("Toggle Dark Mode", self.browser)
        self.toggle_dark_mode_action.triggered.connect(self.toggle_dark_mode)
        self.browser.toolbar.addAction(self.toggle_dark_mode_action)

    def toggle_dark_mode(self):
        self.is_dark_mode = not self.is_dark_mode  # Toggle dark mode state
        self.update_theme()

    def update_theme(self):
        if self.is_dark_mode:
            self.browser.setStyleSheet("QMainWindow { background-color: black; color: white; }")
            self.browser.url_bar.setStyleSheet("QLineEdit { background-color: #333; color: white; }")
            self.browser.tabs.setStyleSheet("QTabWidget::pane { background: #222; } QTabBar::tab { background: #333; color: white; }")
            QMessageBox.information(self.browser, "Dark Mode", "Dark mode has been enabled.")
        else:
            self.browser.setStyleSheet("")
            self.browser.url_bar.setStyleSheet("")
            self.browser.tabs.setStyleSheet("")
            QMessageBox.information(self.browser, "Dark Mode", "Dark mode has been disabled.")
